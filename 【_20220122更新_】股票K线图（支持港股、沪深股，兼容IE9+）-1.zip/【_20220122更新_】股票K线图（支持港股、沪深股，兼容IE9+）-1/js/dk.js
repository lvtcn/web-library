function dk(stock,code,name,lang,_title,_serious){

	var opt_url;

	if(stock === "hk"){
	    opt_url = "http://data.gtimg.cn/flashdata/hk/latest/daily/";
	}else{
	    opt_url = "http://data.gtimg.cn/flashdata/hushen/latest/daily/";
	};


	//  日K
	$.ajax({
	    type: "GET",
	    url: opt_url + stock + code + ".js?maxage=43201&visitDstTime=1",
	    dataType:"script",
	    success:function(){

	        var d_data = format(latest_daily_data,lang);

	        var d_data0 = splitData(d_data);

	        var d_option = opt_dk(name,d_data0,lang,_title,_serious);

	        // 2. 创建echarts实例
	        var myChart = echarts.init(document.getElementById('main'));

	        // 3. 作用
	        myChart.setOption(d_option);
	    }
	});
	
}

// 提示框中文格式回调封装
function tooltip_dk(lang,param,name){
    var html = "";
    if(lang == "CN"){
        var til_op = '开盘值：'
        var til_cl = '收盘值：'
        var til_hi = '最高值：'
        var til_low = '最低值：'
        var value_hi = param[0].value[3]
        var value_low = param[0].value[4]

    }else{
        var til_op = 'open：'
        var til_cl = 'close：'
        var til_hi = 'highest：'
        var til_low = 'lowest：'
        var value_hi = param[0].value[4]
        var value_low = param[0].value[3]
    }
    if(param[0].componentSubType == "candlestick"){
        html += '<div style="text-align:center">' + name + '</div>'
             +  '<div style="text-align:center">' + param[0].name + '</div>'
             + '<div style="white-space: pre-wrap;"></div>'
             + '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:' + param[0].color +'"></span>'
             + param[0].seriesName + "："
             + '<div style="white-space: pre-wrap;"></div>'
             + '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + param[0].color +'"></span>'
             + til_op + toDecimal(param[0].value[1])
             + '<div style="white-space: pre-wrap;"></div>'
             + '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + param[0].color +'"></span>'
             + til_cl + toDecimal(param[0].value[2])
             + '<div style="white-space: pre-wrap;"></div>'
             + '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + param[0].color +'"></span>'
             + til_hi + toDecimal(value_hi)
             + '<div style="white-space: pre-wrap;"></div>'
             + '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + param[0].color +'"></span>'
             + til_low + toDecimal(value_low)
             + '<div style="white-space: pre-wrap;"></div>'
    }
    
    return html;
}

// echarts配置
function opt_dk(name,data,lang,_title,_serious){
    
    // 提示框参数配置
    var setTooltip = {
        trigger: 'axis',
        axisPointer: {
            type: 'cross'
        },
        formatter:function(param){
            return tooltip_dk(lang,param,name)
        }
    };

    // if(lang == "CN"){
    //     setTooltip.formatter = function(param){
            
    //     }
    // };

    // 1. 柱状图样式定义
    var upColor = '#ec0000';
    var upBorderColor = '#8A0000';
    var downColor = '#00da3c';
    var downBorderColor = '#008F28';

    return {
        title: {
            text: _title,
            left: 0
        },
        tooltip: setTooltip,
        // legend: {
        //     data: _legend
        // },
        grid: {
            left: '10%',
            right: '10%',
            bottom: '15%'
        },
        xAxis: {
            type: 'category',
            data: data.categoryData,
            scale: true,
            boundaryGap : false,
            axisLine: {onZero: false},
            splitLine: {show: false},
            splitNumber: 20,
            min: 'dataMin',
            max: 'dataMax'
        },
        yAxis: {
            scale: true,
            splitArea: {
                show: true
            },
            axisPointer: {
                label:{
                    formatter:function(params){
                        return toDecimal(params.value)
                    }
                }
            },
            axisLabel:{
                formatter:function(value,index){
                    return toDecimal(value)
                }
            }
        },
        dataZoom: [
            {
                type: 'inside',
                start: 50,
                end: 100
            },
            {
                show: true,
                type: 'slider',
                y: '90%',
                start: 50,
                end: 100
            }
        ],
        series: [
            {
                name: _serious,
                type: 'candlestick',
                data: data.values,
                itemStyle: {
                    normal: {
                        color: upColor,
                        color0: downColor,
                        borderColor: upBorderColor,
                        borderColor0: downBorderColor
                    }
                },
                markPoint: {
                    label: {
                        normal: {
                            formatter: function (param) {
                                return param != null ? Math.round(param.value) : '';
                            }
                        }
                    },
                    data: [
                        {
                            name: 'XX标点',
                            coord: ['2019/5/31', 2300],
                            value: 2300,
                            itemStyle: {
                                normal: {color: 'rgb(41,60,85)'}
                            }
                        },
                        {
                            name: 'highest value',
                            type: 'max',
                            valueDim: 'highest'
                        },
                        {
                            name: 'lowest value',
                            type: 'min',
                            valueDim: 'lowest'
                        },
                        {
                            name: 'average value on close',
                            type: 'average',
                            valueDim: 'close'
                        }
                    ],
                    tooltip: {
                        formatter: function (param) {
                            return param.name + '<br>' + (param.data.coord || '');
                        }
                    }
                },
                markLine: {
                    symbol: ['none', 'none'],
                    data: [
                        [
                            {
                                name: 'from lowest to highest',
                                type: 'min',
                                valueDim: 'lowest',
                                symbol: 'circle',
                                symbolSize: 10,
                                label: {
                                    normal: {show: false},
                                    emphasis: {show: false}
                                }
                            },
                            {
                                type: 'max',
                                valueDim: 'highest',
                                symbol: 'circle',
                                symbolSize: 10,
                                label: {
                                    normal: {show: false},
                                    emphasis: {show: false}
                                }
                            }
                        ],
                        {
                            name: 'min line on close',
                            type: 'min',
                            valueDim: 'close',
                            label:{
                                formatter:function(param){
                                    return toDecimal(param.value)
                                }
                            }
                        },
                        {
                            name: 'max line on close',
                            type: 'max',
                            valueDim: 'close',
                            label:{
                                formatter:function(param){
                                    return toDecimal(param.value)
                                }
                            }
                        }
                    ]
                }
            },
            // {
            //     name: _legend[1],  
            //     type: 'line',
            //     data: calculateMA(data,5),
            //     smooth: true,
            //     lineStyle: {
            //         normal: {opacity: 0.5},
            //     }
            // },
            // {
            //     name: _legend[2],  
            //     type: 'line',
            //     data: calculateMA(data,10),
            //     smooth: true,
            //     lineStyle: {
            //         normal: {opacity: 0.5}
            //     }
            // },
            // {
            //     name: _legend[3],
            //     type: 'line',
            //     data: calculateMA(data,20),
            //     smooth: true,
            //     lineStyle: {
            //         normal: {opacity: 0.5}
            //     }
            // },
            // {
            //     name: _legend[4],
            //     type: 'line',
            //     data: calculateMA(data,30),
            //     smooth: true,
            //     lineStyle: {
            //         normal: {opacity: 0.5}
            //     }
            // },

        ]
    };

}