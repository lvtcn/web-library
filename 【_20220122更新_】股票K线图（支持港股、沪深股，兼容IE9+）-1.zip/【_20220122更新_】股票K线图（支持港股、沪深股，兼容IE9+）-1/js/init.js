function evil(fn) {
    var Fn = Function;  //一个变量指向Function，防止有些前端编译工具报错
    return new Fn('return ' + fn)();
}
function init(lang,stock,code,chart){

    // if(stock == "hk"){
    //     var preCode = "hk"
    // }else{
    //     var preCode = ""
    // }

    var stk_name,opt_title,opt_legend,opt_serious,p_close;

    // setInterval(function(){
    //     getStock(lang,stock,preCode,code)
    // },60000)


    $.ajax({
        type: "GET",
        url: "http://qt.gtimg.cn/q=" + stock + code,
        // url: "//hq.sinajs.cn/list=" + preCode + code,
        dataType:"script",
        cache:"false",
        success:function(){


            
            // var res = evil("hq_str_" + preCode + code);
            var res = evil("v_" + stock + code);
            console.log(res)
            
            // 获取股票名称
            // if(stock == "hushen"){
            //     stk_name = res.split(",")[0];
            // }else{
            //     stk_name = res.split(",")[0] + res.split(",")[1];
            // };
            stk_name = res.split("~")[1];

            showForLang(lang);

            $(".stc_name").html(stk_name);

            $(".stk-data").find(".stc-name").html(stk_name + "「" + code + "」");

            // --------------------->
            res = res.split('~');

            var zdNum,cjNum,zdHtm;

            //日期时间
            var dtStr = res[30];
            var dt_format = dtStr.substring(0,4) + "-" + dtStr.substring(4,6) + "-" + dtStr.substring(6,8) + "  " + dtStr.substring(8,10) + ":" + dtStr.substring(10,12) + ":" + dtStr.substring(12)
            $('.stk-data').find('.st_date').html(dt_format); 
            // 上一个交易日收盘价
            p_close = res[4];   
            //价格
            $('.stk-data').find('.st_price').html(toDecimal(res[3]));
            // 最新股价
            $('.stk-data').find('.stc_current').html(toDecimal(res[3]));
            // 最高价
            $('.stk-data').find('.stc_max').html(toDecimal(res[33])); 
            // 最低价
            $('.stk-data').find('.stc_min').html(toDecimal(res[34])); 
            // （+/-）涨跌 
            $('.stk-data').find('.stc_updown').html(toDecimal(res[31]));
            // 涨跌幅%  
            $('.stk-data').find('.stc_rate_ud').html(toDecimal(res[32]));
            zdNum = toDecimal(res[32])
            // 买入价
            $('.stk-data').find('.stc_buy').html(toDecimal(res[9]));
            // 卖出价  
            $('.stk-data').find('.stc_sell').html(toDecimal(res[19])); 
            // 成交量（手）
            $('.stk-data').find('.stc_amount').html(showM(lang,res[36]));
            cjNum = showM(lang,res[36])
            // if(stock == "hushen"){
            //     // 上一个交易日收盘价
            //     p_close = res[2];
            //     // 涨幅
            //     zdNum = toDecimal((res[3]-res[2])/res[2]*100);
            //     // 成交量（股）
            //     cjNum = showM(lang,res[8],stock);
            //     //日期时间
            //     $('.stk-data').find('.st_date').html(res[30] +' '+res[31]);
            //     //价格
            //     $('.stk-data').find('.st_price').html(toDecimal(res[3]));
            //     // 最新股价
            //     $('.stk-data').find('.stc_current').html(toDecimal(res[3]));
            //     // 最高价
            //     $('.stk-data').find('.stc_max').html(toDecimal(res[4])); 
            //     // 最低价
            //     $('.stk-data').find('.stc_min').html(toDecimal(res[5])); 

            //     // （+/-）涨跌 = 现价-上一个交易日收盘价
            //     $('.stk-data').find('.stc_updown').html(toDecimal(res[3] - res[2]));
            //     // 涨跌幅%  (现价-上一个交易日收盘价)/上一个交易日收盘价*100%
            //     $('.stk-data').find('.stc_rate_ud').html(toDecimal(zdNum));
            //     // 买入价
            //     $('.stk-data').find('.stc_buy').html(toDecimal(res[6]));
            //     // 卖出价  
            //     $('.stk-data').find('.stc_sell').html(toDecimal(res[7])); 
            //     // 成交量（股）
            //     $('.stk-data').find('.stc_amount').html(showM(lang,res[8],stock));

            // }else{
            //     // 上一个交易日收盘价
            //     p_close = res[3];
            //     // 涨幅
            //     zdNum = toDecimal((res[6]-res[3])/res[3]*100);
            //     // 成交量（股）
            //     cjNum = showM(lang,res[12],stock);
            //     //日期时间
            //     $('.stk-data').find('.st_date').html(res[17].replace(/\//ig,'-')+' '+res[18]);
            //     //价格
            //     $('.stk-data').find('.st_price').html(toDecimal(res[6]));
            //     // 最新股价
            //     $('.stk-data').find('.stc_current').html(toDecimal(res[6])); 
            //     // 最高价
            //     $('.stk-data').find('.stc_max').html(toDecimal(res[4]));
            //     // 最低价
            //     $('.stk-data').find('.stc_min').html(toDecimal(res[5]));
            //     // （+/-）涨跌
            //     $('.stk-data').find('.stc_updown').html(toDecimal(res[7])); 
            //     // 涨跌幅%
            //     $('.stk-data').find('.stc_rate_ud').html(toDecimal(res[8]));
            //     // 买入价
            //     $('.stk-data').find('.stc_buy').html(toDecimal(res[9]));
            //     // 卖出价  
            //     $('.stk-data').find('.stc_sell').html(toDecimal(res[10]));
            //     // 成交量（股）
            //     $('.stk-data').find('.stc_amount').html(showM(lang,res[12],stock)); 
            // }
            
            
            if(zdNum > 0){
                $('.stk-data').find('.st_zd').addClass('zd_down');
                zdHtm = zdNum+'%'
            }else{
                $('.stk-data').find('.st_zd').addClass('zd_up')
                zdHtm = zdNum+'%'
            }
            //涨幅
            $('.stk-data').find('.st_zd').html(zdHtm);
    
            //成交数
            $('.stk-data').find('.st_cj').html(cjNum);

            optForLang(lang,stock,code,stk_name,chart,p_close);
             
        }
    });

    

    $(".stc-lang").find("a").each(function(){
        $(this).on("click",function(){
            $(this).addClass("now").siblings("a").removeClass("now");
            var iLang = $(this).data("val")
            showForLang(iLang);
            var getVol = $(".stc-left.active").find(".st_cj").text();

            if(getVol.indexOf("万") > 0){
                getVol = parseFloat(getVol) * 10000
            }else if(getVol.indexOf("k") > 0){
                getVol = parseFloat(getVol) * 1000
            }else if(getVol.indexOf("mil") > 0){
                getVol = parseFloat(getVol) * 1000000
            };
            $(".stc-left.active").find(".st_cj").text(showM(iLang,getVol));
            $(".stc_amount").text(showM(iLang,getVol))
            optForLang(iLang,stock,code,stk_name,chart,p_close)
        })
    });

    
    $(".kke_menus_tab_normal").each(function(index,tab){
        $(this).on("click",function(){
            $(this).addClass("kke_menus_tab_active").siblings().removeClass("kke_menus_tab_active");
            var myId = $(this).data("id");
            var lang = $(".stc-lang").find("a.now").data("val");
            if(chart){
                // 清空当前实例
                chart.clear();
            };
            var iLang = $(".stc-lang").find("a.now").data("val");
            if(iLang === "CN"){
                switch(stock){
                    case "hushen":
                        opt_title = "上证指数";
                        break;
                    case "hk":
                        opt_title = "恒生指数";
                        break;
                };
            }else{
                switch(stock){
                    case "hushen":
                        opt_title = "SSEC";
                        break;
                    case "hk":
                        opt_title = "HSI";
                        break;
                };
                
            };
            switch(myId){
                case "t1":
                    t1(stock,code,stk_name,lang,opt_title,p_close);
                    break;

                case "t5":
                    if(stock == "hk"){
                        t5_hk(code,stk_name,lang,opt_title);
                    }else{
                        t5(stock,code,stk_name,lang,opt_title);
                    }
                    
                    break;

                case "kd":
                    if(lang === "CN"){
                        opt_serious = "日K";
                    }else{
                        opt_serious = "1D";
                    }
                    dk(stock,code,stk_name,lang,opt_title,opt_serious);
                    break;

                case "kw":
                    if(lang === "CN"){
                        opt_serious = "周K";
                    }else{
                        opt_serious = "1W";
                    }
                    wk(stock,code,stk_name,lang,opt_title,opt_serious);
                    break;

                case "km":
                    if(lang === "CN"){
                        opt_serious = "月K";
                    }else{
                        opt_serious = "1M";
                    }
                    mk(stock,code,stk_name,lang,opt_title,opt_serious);
                    break;

                case "ky":
                    if(lang === "CN"){
                        opt_serious = "年K";
                    }else{
                        opt_serious = "1Y";
                    }
                    yk(stock,code,stk_name,lang,opt_title,opt_serious);
                    break;
            }
        })
    })

    
}

function showForLang(lang){

    if(lang == "CN"){
        $(".stc-left-cn").addClass("active");
        $(".stc-left-en").removeClass("active");
        $(".pc_tb").find(".thead_cn").addClass("active");
        $(".pc_tb").find(".thead_en").removeClass("active");
        $(".wap_tb").find(".thead_cn").addClass("active");
        $(".wap_tb").find(".thead_en").removeClass("active");
        $(".kke_menus_tab_edage.tab_cn").addClass("active");
        $(".kke_menus_tab_edage.tab_en").removeClass("active");

    }else{
        $(".stc-left-cn").removeClass("active");
        $(".stc-left-en").addClass("active");
        $(".pc_tb").find(".thead_cn").removeClass("active");
        $(".pc_tb").find(".thead_en").addClass("active");
        $(".wap_tb").find(".thead_cn").removeClass("active");
        $(".wap_tb").find(".thead_en").addClass("active");
        $(".kke_menus_tab_edage.tab_cn").removeClass("active");
        $(".kke_menus_tab_edage.tab_en").addClass("active");
    };

}

function optForLang(lang,stock,code,name,chart,close){

    if(lang === "CN"){
        switch(stock){
            case "sh":
                opt_title = "上证指数";
                break;
            case "sz":
                opt_title = "上证指数";
                break;
            case "hk":
                opt_title = "恒生指数";
                break;
        };
        opt_legend = ['日K','5日均线','10日均线', '20日均线', '30日均线'],
        opt_serious = "日K";
        

    }else{
        switch(stock){
            case "sh":
                opt_title = "SSEC";
                break;
            case "sz":
                opt_title = "SSEC";
                break;
            case "hk":
                opt_title = "HSI";
                break;
        };
        opt_legend = ['1D', 'MA5', 'MA10', 'MA20', 'MA30']
        opt_serious = "1D";
    };

    if(chart){
        // 清空当前实例
        chart.clear();
    };

    $(".kke_menus_tab_edage.active").find(".kke_menus_tab_normal").each(function(){
        if($(this).hasClass("kke_menus_tab_active")){
            var getId = $(this).data("id");
            switch(getId){
                case "t1":
                    t1(stock,code,name,lang,opt_title,close);
                    break;

                case "t5":
                    if(stock == "hk"){
                        t5_hk(code,name,lang,opt_title);
                    }else{
                        t5(code,name,lang,opt_title);
                    }
                    
                    break;

                case "kd":
                    if(lang === "CN"){
                        opt_serious = "日K";
                    }else{
                        opt_serious = "1D";
                    }

                    dk(stock,code,name,lang,opt_title,opt_serious);
                    break;

                case "kw":
                    if(lang === "CN"){
                        opt_serious = "周K";
                    }else{
                        opt_serious = "1W";
                    }
                    wk(stock,code,name,lang,opt_title,opt_serious);
                    break;

                case "km":
                    if(lang === "CN"){
                        opt_serious = "月K";
                    }else{
                        opt_serious = "1M";
                    }
                    mk(stock,code,name,lang,opt_title,opt_serious);
                    break;

                case "ky":
                    if(lang === "CN"){
                        opt_serious = "年K";
                    }else{
                        opt_serious = "1Y";
                    }
                    yk(stock,code,name,lang,opt_title,opt_serious);
                    break;
            }
        }
    })

};



function getStock(lang,stock,preCode,code){

    $.ajax({
        type: "GET",
        url: "http://qt.gtimg.cn/q=" + stock + code,
        dataType:"script",
        cache:"false",
        success:function(){
            
            var res = evil("v_" + stock + code);
            
            // 获取股票名称
            // if(stock == "hushen"){
            //     stk_name = res.split(",")[0];
            // }else{
            //     stk_name = res.split(",")[0] + res.split(",")[1];
            // };
            
            stk_name = res.split("~")[1];

            showForLang(lang);

            $(".stc_name").html(stk_name);

            $(".stk-data").find(".stc-name").html(stk_name + "「" + code + "」");

            // --------------------->
            res = res.split('~');
            var zdNum,cjNum,zdHtm;

            //日期时间
            var dtStr = res[30];
            var dt_format = dtStr.substring(0,4) + "-" + dtStr.substring(4,6) + "-" + dtStr.substring(6,8) + "  " + dtStr.substring(8,10) + ":" + dtStr.substring(10,12) + ":" + dtStr.substring(12)
            $('.stk-data').find('.st_date').html(dt_format);    
            //价格
            $('.stk-data').find('.st_price').html(toDecimal(res[3]));
            // 最新股价
            $('.stk-data').find('.stc_current').html(toDecimal(res[3]));
            // 最高价
            $('.stk-data').find('.stc_max').html(toDecimal(res[33])); 
            // 最低价
            $('.stk-data').find('.stc_min').html(toDecimal(res[34])); 
            // （+/-）涨跌 
            $('.stk-data').find('.stc_updown').html(toDecimal(res[31]));
            // 涨跌幅%  
            $('.stk-data').find('.stc_rate_ud').html(toDecimal(res[32]));
            zdNum = toDecimal(res[32])
            // 买入价
            $('.stk-data').find('.stc_buy').html(toDecimal(res[9]));
            // 卖出价  
            $('.stk-data').find('.stc_sell').html(toDecimal(res[19])); 
            // 成交量（手）
            $('.stk-data').find('.stc_amount').html(showM(lang,res[36]));
            cjNum = showM(lang,res[36])

            // if(stock == "hushen"){
            //     // 上一个交易日收盘价
            //     // p_close = res[2];
            //     // 涨幅
            //     // zdNum = toDecimal((res[3]-res[2])/res[2]*100);
            //     // 成交量（股）
            //     // cjNum = showM(lang,res[8],stock);
            //     //日期时间
            //     // $('.stk-data').find('.st_date').html(res[30] +' '+res[31]);
            //     // $('.stk-data').find('.st_date').html(res[30] );
            //     //价格
            //     $('.stk-data').find('.st_price').html(toDecimal(res[3]));
            //     // 最新股价
            //     $('.stk-data').find('.stc_current').html(toDecimal(res[3]));
            //     // 最高价
            //     $('.stk-data').find('.stc_max').html(toDecimal(res[4])); 
            //     // 最低价
            //     $('.stk-data').find('.stc_min').html(toDecimal(res[5])); 

            //     // （+/-）涨跌 = 现价-上一个交易日收盘价
            //     $('.stk-data').find('.stc_updown').html(toDecimal(res[3] - res[2]));
            //     // 涨跌幅%  (现价-上一个交易日收盘价)/上一个交易日收盘价*100%
            //     $('.stk-data').find('.stc_rate_ud').html(toDecimal(zdNum));
            //     // 买入价
            //     $('.stk-data').find('.stc_buy').html(toDecimal(res[6]));
            //     // 卖出价  
            //     $('.stk-data').find('.stc_sell').html(toDecimal(res[7])); 
            //     // 成交量（股）
            //     $('.stk-data').find('.stc_amount').html(showM(lang,res[8],stock));

            // }else{
            //     // 上一个交易日收盘价
            //     // p_close = res[3];
            //     // // 涨幅
            //     // zdNum = toDecimal((res[6]-res[3])/res[3]*100);
            //     // // 成交量（股）
            //     // cjNum = showM(lang,res[12],stock);
            //     // //日期时间
            //     // $('.stk-data').find('.st_date').html(res[17].replace(/\//ig,'-')+' '+res[18]);
            //     // //价格
            //     // $('.stk-data').find('.st_price').html(toDecimal(res[6]));
            //     // // 最新股价
            //     // $('.stk-data').find('.stc_current').html(toDecimal(res[6])); 
            //     // // 最高价
            //     // $('.stk-data').find('.stc_max').html(toDecimal(res[4]));
            //     // // 最低价
            //     // $('.stk-data').find('.stc_min').html(toDecimal(res[5]));
            //     // // （+/-）涨跌
            //     // $('.stk-data').find('.stc_updown').html(toDecimal(res[7])); 
            //     // // 涨跌幅%
            //     // $('.stk-data').find('.stc_rate_ud').html(toDecimal(res[8]));
            //     // // 买入价
            //     // $('.stk-data').find('.stc_buy').html(toDecimal(res[9]));
            //     // // 卖出价  
            //     // $('.stk-data').find('.stc_sell').html(toDecimal(res[10]));
            //     // // 成交量（股）
            //     // $('.stk-data').find('.stc_amount').html(showM(lang,res[12],stock)); 
            // }
            
            
            if(zdNum > 0){
                $('.stk-data').find('.st_zd').addClass('zd_down');
                zdHtm = zdNum+'%'
            }else{
                $('.stk-data').find('.st_zd').addClass('zd_up')
                zdHtm = zdNum+'%'
            }
            //涨幅
            $('.stk-data').find('.st_zd').html(zdHtm);
    
            //成交数
            $('.stk-data').find('.st_cj').html(cjNum);
             
        }
    });


}
